package com.example.minhas_viagens

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
